
// Seyed Tavafi
// CS3560
// miniTweeter project 3
package Observers;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LastActivityObserver {
    private Date date;

    /*
     * this method update last activity
     * return LastActivityObserver
     */
    public LastActivityObserver update() {
        this.date = new Date();
        return this;
    }

    /*
     * this method get date by string type
     * return dateFormat
     */
    public String getStringDate() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        return dateFormat.format(date);
    }

    /*
     * this method get date by Date type
     * return date
     */
    public Date getDate() {
        return date;
    }
}
