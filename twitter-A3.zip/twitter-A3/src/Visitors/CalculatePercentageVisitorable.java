  
// Seyed Tavafi
// CS3560
// miniTweeter project 3
package Visitors;

import Pool.Pool;

/*
 * this method to visit
 * return find word count
 */
public interface CalculatePercentageVisitorable {
    public double visit(Pool pool,String word);
}
